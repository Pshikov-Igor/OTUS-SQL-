gif'ки с JOIN отсюда:

https://bertwagner.com/posts/visualizing-nested-loops-joins-and-understanding-their-implications/
https://bertwagner.com/posts/visualizing-merge-join-internals-and-understanding-their-implications/
https://bertwagner.com/posts/hash-match-join-internals/