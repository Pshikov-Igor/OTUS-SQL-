--do not run on Prod
-- https://docs.microsoft.com/ru-ru/sql/t-sql/database-console-commands/dbcc-freeproccache-transact-sql?view=sql-server-ver15
DBCC FREEPROCCACHE 
GO 
DBCC DROPCLEANBUFFERS 
Go 
-- https://docs.microsoft.com/ru-ru/sql/t-sql/database-console-commands/dbcc-freesystemcache-transact-sql?view=sql-server-ver15
DBCC FREESYSTEMCACHE ('ALL') 
GO 
DBCC FREESESSIONCACHE 
GO

Declare @dbid int
select @dbid = database_id
from sys.databases
where name = 'WideWorldImporters'

DBCC FLUSHPROCINDB(@dbid) 
GO
