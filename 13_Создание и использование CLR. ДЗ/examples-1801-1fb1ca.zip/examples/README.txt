﻿01-SimpleDemo
-------------

01-SimpleDemo - пример проекта с ручной регистрацией сборки в SQL Server.
Без использования каких-то специальных средств Visual Studio.

02-DatabaseProjectDemo
----------------------

02-DatabaseProjectDemo - пример SQL Server Database Project в Visual Studio.

Для открытия проекта необходимо установить SQL Server Data Tools (SSDT).

https://docs.microsoft.com/ru-ru/sql/ssdt/download-sql-server-data-tools-ssdt

